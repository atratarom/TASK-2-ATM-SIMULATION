# TASK-2-ATM-SIMULATION
This is my Exam task project
